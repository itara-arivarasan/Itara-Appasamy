from odoo import api, fields, models

class SaleOrderConfirm(models.Model):
    _name = 'sale.confirm.wizard'

    # sale_order_id = fields.Many2one('sale.order', "Sale order")
    product_id = fields.Many2one("product.template", "Product Name")
    partner_id = fields.Many2one('res.partner', "Customer")
    email = fields.Char("Email")
    mobile = fields.Char("Phone No")
    # partner_id = fields.Many2one('res.partner', "Customer")
    order_type_id = fields.Many2one('sale.order.type', "Order Type")
    specific_req = fields.Char("Specific Requirements")
    change_spec = fields.Char("Change on Specification")
    access_req = fields.Char("Accessories requirement")
    qty = fields.Char("Quantity")
    exp_del_date = fields.Char("Expected Delivery Date")
    despatch_id = fields.Many2one("despatch.master", "Delivery Method")
    place_dispatch = fields.Many2one("city.master", "Place Of Dispatch")
    price = fields.Char("Price")
    condition_proposal = fields.Char("Conditions differs from proposal / Quantization.Tender")
    transport_charge = fields.Char("Transport/Frieght Charges")
    install_req = fields.Char("Installation Requirements")
    demo = fields.Char("Demo / User Training")
    add_warrenty = fields.Char("Additional Warrenty")
    tax_other = fields.Char("Tax, Excise and other applicable duties ")
    add_warrenty = fields.Char("Additional Warrenty")
    packing_req = fields.Char("Special Packing")
    regulatory = fields.Char("Regulatory")
    approver = fields.Char("Approver")
    reason = fields.Char("Reason for Cancel")

