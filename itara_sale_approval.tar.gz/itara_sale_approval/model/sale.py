# -*- coding: utf-8 -*-

from odoo import api, fields, models, _
from odoo.exceptions import UserError

class SaleApproval(models.Model):
    _inherit = 'sale.order'
    
    @api.multi
    @api.depends('order_line', 'order_line.price_unit', 'order_line.fix_discount', 'order_line.discount', 'self.global_discount', 'self.order_type')
    def check_approval_update(self):
        notify_user = self.env['res.users']
        for order in self:
            discount = any(order.order_line.filtered(lambda x: x.fix_discount > 0.0 or x.discount > 0.0))
            if discount == True:
                if any(order.order_line.filtered(lambda x: x.fix_discount > 0.0 or x.discount > 0.0)):
                    order.state = 'to_be_approved'
            if order.global_discount > 0.0:
                order.state = 'to_be_approved'
            if order.order_type.name == "Demo":
                order.state = 'to_be_approved'
            if order.order_type.name == "Free":
                order.state = 'to_be_approved'
            if notify_user:
                order.message_subscribe_users(user_ids=[notify_user.id])

    @api.model
    def create(self, vals):
        order = super(SaleApproval, self).create(vals)
        discount = any(order.order_line.filtered(lambda x: x.fix_discount > 0.0 or x.discount > 0.0))
        if discount == True:
            if any(order.order_line.filtered(lambda x: x.fix_discount > 0.0 or x.discount > 0.0)):
                order.state = 'to_be_approved'
        if order.global_discount > 0.0 :
            order.state = 'to_be_approved'
        if order.order_type.name == "Demo":
            order.state = 'to_be_approved'
        if order.order_type.name == "Free":
            order.state = 'to_be_approved'
        return order

