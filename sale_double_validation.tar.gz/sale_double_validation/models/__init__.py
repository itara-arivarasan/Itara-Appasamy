# -*- coding: utf-8 -*-

from . import sale_double_validation
