# -*- coding: utf-8 -*-

from odoo import api, fields, models, _
from odoo.exceptions import UserError

class ProductCategory(models.Model):
    _inherit = 'product.category'

    user_id = fields.Many2one('res.users', 'Category Manger')

class SaleOrder(models.Model):
    _inherit = 'sale.order'

    is_login_user = fields.Boolean('Is Login User', compute='_check_is_login_user')
    state = fields.Selection(selection_add=[('to_be_approved', 'Waiting for approval'), ('approved', 'Approved'), ('refused', 'Refused')])

    @api.depends('user_id', 'order_line')
    def _check_is_login_user(self):
        for order in self:
            if order.order_line.filtered(lambda x: x.product_template_id.attribute_line_ids):
                product_categ_id = order.order_line and order.order_line[0].product_template_id.categ_id
                if product_categ_id and all([line.product_template_id.categ_id == product_categ_id for line in order.order_line]):
                    if product_categ_id.user_id and product_categ_id.user_id == self.env.user:
                        order.is_login_user = True
                    else:
                        order.is_login_user = False
            else:
                product_categ_id = order.order_line and order.order_line[0].product_id.categ_id
                if product_categ_id and all([line.product_id.categ_id == product_categ_id for line in order.order_line]):
                    if product_categ_id.user_id and product_categ_id.user_id == self.env.user:
                        order.is_login_user = True
                    else:
                        order.is_login_user = False

    @api.multi
    def _track_subtype(self, init_values):
        for rec in self:
            if 'state' in init_values and rec.state == 'to_be_approved':
                return 'sale_double_validation.sale_request_to_be_approved'
            elif 'state' in init_values and rec.state == 'approved':
                return 'sale_double_validation.sale_request_approved'
            elif 'state' in init_values and rec.state == 'refused':
                return 'sale_double_validation.sale_request_refused'
        return super(SaleOrder, self)._track_subtype(init_values)

    @api.multi
    def make_approved(self):
        for order in self:
            order.write({'state': 'approved'})

    @api.multi
    def action_refused(self):
        for order in self:
            order.write({'state': 'refused'})

    @api.multi
    def action_split_product_line(self):
        res = super(SaleOrder, self).action_split_product_line()
        self.check_product_price_update()
        self.compute_taxes()
        self.check_approval_update()
        return res

    @api.multi
    @api.depends('order_line', 'order_line.price_unit')
    def check_product_price_update(self):
        notify_user = self.env['res.users']
        for order in self:
            if order.order_line.filtered(lambda x: x.product_template_id.attribute_line_ids):
                notify_user = order.order_line and order.order_line[0].product_template_id.categ_id.user_id
            else:
                notify_user = order.order_line and order.order_line[0].product_id.categ_id.user_id
            if any(order.order_line.filtered(lambda x: x.price_unit != x._check_price_with_pricelist())):
                order.state = 'to_be_approved'
            if notify_user:
                order.message_subscribe_users(user_ids=[notify_user.id])

    @api.model
    def create(self, vals):
        order = super(SaleOrder, self).create(vals)
        if order.order_line.filtered(lambda x: not x.product_template_id.attribute_line_ids):
            if any(order.order_line.filtered(lambda x: x.price_unit != x._check_price_with_pricelist())):
                order.state = 'to_be_approved'
        return order


class SaleOrderLine(models.Model):
    _inherit = 'sale.order.line'

    @api.onchange('product_id')
    def product_id_change(self):
        if self.product_id and self.product_id.categ_id and not self.product_id.categ_id.user_id:
            raise UserError(_('Category manager not assign in product %s' % self.product_id.name))
        return super(SaleOrderLine, self).product_id_change()

    @api.onchange('product_template_id')
    def _onchange_product_template(self):
        if self.product_template_id and self.product_template_id.categ_id and not self.product_template_id.categ_id.user_id:
            raise UserError(_('Category manager not assign in product template %s' % self.product_template_id.name))
        return super(SaleOrderLine, self)._onchange_product_template()

    def _check_price_with_pricelist(self):
        if self.order_id.pricelist_id and self.order_id.partner_id:
            if self.filtered(lambda x: x.product_template_id.attribute_line_ids):
                product = self.product_template_id.with_context(
                    lang=self.order_id.partner_id.lang,
                    partner=self.order_id.partner_id.id,
                    quantity=self.product_uom_qty,
                    date=self.order_id.date_order,
                    pricelist=self.order_id.pricelist_id.id,
                    uom=self.product_uom.id,
                    fiscal_position=self.env.context.get('fiscal_position')
                )
            else:
                product = self.product_id.with_context(
                    lang=self.order_id.partner_id.lang,
                    partner=self.order_id.partner_id.id,
                    quantity=self.product_uom_qty,
                    date=self.order_id.date_order,
                    pricelist=self.order_id.pricelist_id.id,
                    uom=self.product_uom.id,
                    fiscal_position=self.env.context.get('fiscal_position')
                )
            amount = self.env['account.tax']._fix_tax_included_price_company(self._get_display_price(product), product.taxes_id, self.tax_id, self.company_id)
            return amount
