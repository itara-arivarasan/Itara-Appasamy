# -*- coding: utf-8 -*-

{
    "name": "Sale Double Validation",
    "version": "11.0",
    "summary": "Without approval, user not allowed to sale in less then product price",
    "category": "Sales",
    "depends": ['sale_management', 'sale_stock', 'sale_dynamic_variants'],
    "description": "User has to take approval from category manager. when they want to sale in less then product price on sale order",
    "data": [
        "security/ir.model.access.csv",
        "data/sale_validation_data.xml",
        "views/sale_double_validation_view.xml",
    ],
    'installable': True,
    'auto_install': False,
}
