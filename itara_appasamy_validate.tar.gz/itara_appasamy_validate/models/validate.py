from odoo import api, fields, models, _
from odoo.exceptions import UserError


class Invoice(models.Model):
    _inherit = 'account.invoice'

    pan_checked = fields.Boolean(string="Pan Checked", default=False)

    @api.multi
    def action_invoice_open(self):
        if self.amount_total > 200000:
            if not self.pan_checked:
                view = self.env.ref('itara_appasamy_validate.validate_wizard_form_view')
                wiz = self.env['validate.wizard'].create({'invoice_id': self.id})
                return {
                    'name': 'Warning',
                    'type': 'ir.actions.act_window',
                    'view_type': 'form',
                    'view_mode': 'form',
                    'res_model': 'validate.wizard',
                    'views': [(view.id, 'form')],
                    'view_id': view.id,
                    'target': 'new',
                    'res_id': wiz.id,
                    'context': self.env.context,}
            else:
                return super(Invoice, self).action_invoice_open()
        else:
            return super(Invoice, self).action_invoice_open()
