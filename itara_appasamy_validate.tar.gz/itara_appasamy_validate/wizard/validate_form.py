from odoo import api, fields, models

class Validate(models.Model):
    _name = 'validate.wizard'

    invoice_id = fields.Many2one('account.invoice', "Invoice")

    @api.multi
    def action_confirm(self):
        invoice = self.invoice_id
        invoice.write({'pan_checked': True})

        return True


   











    
