# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from odoo import tools
from odoo import api, fields, models


class ProductVariety(models.Model):
    _name = "product.variety"

    name = fields.Char()

class ProductType(models.Model):
    _name = "product.type"

    name = fields.Char()


class ProductVision(models.Model):
    _name = "product.vision"

    name = fields.Char()


class CustomCategory(models.Model):
    _name = "custom.category"

    name = fields.Char()

class ProductSubCategory(models.Model):
    _name = "product.template.sub.category"

    name = fields.Char()

class ProductTemplate(models.Model):
    _inherit = "product.template"

    variety_id = fields.Many2one('product.variety', 'Product Variety')
    product_sub_category_id = fields.Many2one('product.template.sub.category', 'Product Sub-Category')
    prod_type_id = fields.Many2one('product.type', 'Product Type')
    indian_imported = fields.Selection([('indian', 'Indian'), ('imported', 'Imported')], 'Indian/Imported')
    premium_non_premium = fields.Selection([('premium', 'Premium'), ('non_premium', 'Non Premium')], 'Premium/Non Premium')
    vision_non_vision = fields.Selection([('vision', 'Vision'), ('non_vision', 'Non vision')], 'Vision/Non vision')
    vision_id = fields.Many2one('product.vision', 'Vision Name')
    manager_id = fields.Many2one('res.users', 'Product Manager')
    first_email = fields.Char(string="Email 1")
    second_email = fields.Char(string="Email 2")
    third_email = fields.Char(string="Email 3")
    custom_categ_id = fields.Many2one('custom.category', 'Category')
