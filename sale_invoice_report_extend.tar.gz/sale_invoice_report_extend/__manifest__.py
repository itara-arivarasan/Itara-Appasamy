# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

{
    'name': 'Itara Sales Analysis report: Group by Custom objects',
    'version': '11.0',
    'summary': 'Check Invoice from Sale Order',
    'description': """
 - Group by multiple objects
     """,
    'depends': ['sale_management'],
    'data': [
        'security/sale_invoice_security.xml',
        'security/ir.model.access.csv',        
        'views/product_view.xml',
        'views/invoice_report_extended.xml',
        'views/sale_report_extended.xml',
      ],
    'installable': True,
    'application': False,
}
