# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.
{
    'name': 'Sale Order Report',
    "version": "11.0.1.0.0",
    'summary': 'Itara/Sowndharya',
    'description': """Sale Order Report""",
    'category': 'sale',
    'depends': ['base_setup', 'sale'],
    'data': ['sale_order_report.xml', 'sale_order_report_view.xml', 'sale_delivery_report.xml', 'sale_delivery_report_view.xml'],
    'installable': True,
    'application': True,
    'auto_install': False,

}
