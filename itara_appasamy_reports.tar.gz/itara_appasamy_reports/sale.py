from odoo import api, fields, models, _


class SaleOrderLine(models.Model):
    _inherit = "sale.order.line"

    @api.one
    @api.depends('product_id')
    def _compute_variant_name(self):
        for rec in self.sudo():
            # display only the attributes with multiple possible values on the template
            variable_attributes = rec.product_id.attribute_line_ids.filtered(lambda l: len(l.value_ids) > 1).mapped('attribute_id')
            variant = rec.product_id.attribute_value_ids._variant_name(variable_attributes)
            self.power = variant

    @api.one
    @api.depends('order_id')
    def _compute_serial_number(self):
        for sale in self.order_id:
            picking = self.env['stock.picking'].search([('name', '=', sale.name)])
            for picking in picking:
                for pick_line in picking.move_lines:
                    if pick_line.product_id == rec.product_id:
                        move_line = self.env['stock.move.line'].search([('move_id', '=', pick_line.id), ('product_id', '=', pick_line.product_id.id)])
                        lot_name = move_line.lot_id.name
                        self.serial_number = lot_name

    power = fields.Char(string="Power", compute='_compute_variant_name', store=True)
    serial_number = fields.Char(string="Serial Number", compute='_compute_serial_number', store=True)




