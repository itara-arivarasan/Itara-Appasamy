# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.import xlwt
import io
from io import StringIO
import base64
import time
import xlwt
from datetime import datetime, date, timedelta
from dateutil import relativedelta
from odoo import models, fields, api, _, exceptions

class DetailedInvoiceReport(models.Model):
    _name = 'detailed.invoice.report'

    name = fields.Char(string="Name")
    company_id = fields.Many2one('res.company', string='Company', default=lambda self: self.env.user.company_id, readonly=True)
    start_date = fields.Date(string='Start Date', required=True)
    end_date = fields.Date(string='End Date', required=True)

    def get_data(self):
        workbook = xlwt.Workbook()
        title_style_center = xlwt.easyxf('align: horiz center ;font: name Times New Roman,bold off, italic off')
        title_style_left = xlwt.easyxf('font: name Times New Roman, height 200;align: horiz left ')
        title_style_right = xlwt.easyxf('font: name Times New Roman, height 200;align: horiz right ')
        title_style1_table_head_right = xlwt.easyxf(
            'font: name Times New Roman,bold on, italic off, height 200;align: horiz right ;')
        title_style1_table_head_center = xlwt.easyxf(
            'align: horiz center ;font: name Times New Roman,bold on, italic off, height 200')
        title_style1_table_head_left = xlwt.easyxf(
            'align: horiz left ;font: name Times New Roman,bold on, italic off, height 200')

        row_date_count = 0

        #        B2B Invoice

        customers = []
        sheet = workbook.add_sheet('Detailed Invoice Analysis Report')
        sheet.write(row_date_count, 0, "S.No", title_style1_table_head_center)
        sheet.write(row_date_count, 1, "Category", title_style1_table_head_center)
        sheet.write(row_date_count, 2, "Year", title_style1_table_head_center)
        sheet.write(row_date_count, 3, "Branch Name", title_style1_table_head_center)
        sheet.write(row_date_count, 4, "DC No", title_style1_table_head_center)
        sheet.write(row_date_count, 5, "DC Date", title_style1_table_head_center)
        sheet.write(row_date_count, 6, "Segment Name", title_style1_table_head_center)
        sheet.write(row_date_count, 7, "Customer Name", title_style1_table_head_center)
        sheet.write(row_date_count, 8, "District Name", title_style1_table_head_center)
        sheet.write(row_date_count, 9, "City Name", title_style1_table_head_center)
        sheet.write(row_date_count, 10, "Corrected Product ", title_style1_table_head_center)
        sheet.write(row_date_count, 11, "Product Name", title_style1_table_head_center)
        sheet.write(row_date_count, 12, "Qty", title_style1_table_head_center)
        sheet.write(row_date_count, 13, "RPU ", title_style1_table_head_center)
        sheet.write(row_date_count, 14, "Total", title_style1_table_head_center)
        sheet.write(row_date_count, 15, "CR Qty", title_style1_table_head_center)
        sheet.write(row_date_count, 16, "CR Total ", title_style1_table_head_center)
        sheet.write(row_date_count, 17, "ActQty", title_style1_table_head_center)
        sheet.write(row_date_count, 18, "Act Amount", title_style1_table_head_center)
        row_date_count += 1
        count = 0        
        values = []
        for invoice in self.env['account.invoice'].search([('date_invoice', '>=', self.start_date), ('date_invoice', '<=', self.end_date),('type', '=', 'out_invoice')]):
            for line in invoice.invoice_line_ids:
                return_line = self.env['account.invoice.line'].search([('return_inv', '=', line.return_inv), ('product_id', '=', line.product_id.id), ('invoice_id.type', '=', 'out_refund')])
                if return_line:
                    for rline in return_line:
                        data = {'categ_id': line.product_id.product_tmpl_id.categ_id.name or False,
                        'inv_year': line.invoice_id.date_invoice[:-6] or False,
                        'branch': line.invoice_id.partner_id.branch_id.name or False,
                        'number': line.invoice_id.number or False,
                        'date': line.invoice_id.date_invoice or False,
                        'sub_division': line.invoice_id.partner_id.sub_division_id.name or False,
                        'customer': line.invoice_id.partner_id.name or False,
                        'district': line.invoice_id.partner_id.district_id.name or False,
                        'city': line.invoice_id.partner_id.city_id.name or False,
                        'type': line.product_id.product_tmpl_id.prod_type_id.name or False,
                        'product': line.product_id.product_tmpl_id.name + '(' + line.power + ')' or False,
                        'quantity': line.quantity,
                        'price_subtotal': line.price_subtotal,
                        'unit_price': line.price_unit,
                        'rquantity':rline.quantity,
                        'rprice_subtotal': rline.price_subtotal,
                        'actqty': line.quantity - rline.quantity,
                        'actamount': line.price_subtotal - rline.price_subtotal
                         }
                        values.append(data)
                if not return_line:
                    data = {'categ_id': line.product_id.product_tmpl_id.categ_id.name or False,
                        'inv_year': line.invoice_id.date_invoice[:-6] or False,
                        'branch': line.invoice_id.partner_id.branch_id.name or False,
                        'number': line.invoice_id.number or False,
                        'date': line.invoice_id.date_invoice or False,
                        'sub_division': line.invoice_id.partner_id.sub_division_id.name or False,
                        'customer': line.invoice_id.partner_id.name or False,
                        'district': line.invoice_id.partner_id.district_id.name or False,
                        'city': line.invoice_id.partner_id.city_id.name or False,
                        'type': line.product_id.product_tmpl_id.prod_type_id.name or False,
                        'product': line.product_id.product_tmpl_id.name + '(' + line.power + ')' or False,
                        'quantity': line.quantity,
                        'price_subtotal': line.price_subtotal,
                        'unit_price': line.price_unit,
                        'rquantity':0.0,
                        'rprice_subtotal': 0.0,
                        'actqty': line.quantity,
                        'actamount': line.price_subtotal
                         }
                    values.append(data)         
        for val in values: 
            count += 1
            sheet.write(row_date_count, 0, count, title_style_left)
            sheet.write(row_date_count, 1, val['categ_id'], title_style_left)
            sheet.write(row_date_count, 2, val['inv_year'], title_style_left)
            sheet.write(row_date_count, 3, val['branch'], title_style_left)
            sheet.write(row_date_count, 4, val['number'], title_style_left)
            sheet.write(row_date_count, 5, val['date'], title_style_left)
            sheet.write(row_date_count, 6, val['sub_division'], title_style_left)
            sheet.write(row_date_count, 7, val['customer'], title_style_left)
            sheet.write(row_date_count, 8, val['district'], title_style_left)
            sheet.write(row_date_count, 9, val['city'], title_style_left)
            sheet.write(row_date_count, 10, val['type'], title_style_left)
            sheet.write(row_date_count, 11, val['product'], title_style_left)
            sheet.write(row_date_count, 12, val['quantity'], title_style_left)
            sheet.write(row_date_count, 13, val['unit_price'], title_style_left)
            sheet.write(row_date_count, 14, val['price_subtotal'], title_style_left)
            sheet.write(row_date_count, 15, val['rquantity'], title_style_left)
            sheet.write(row_date_count, 16, val['rprice_subtotal'], title_style_left)
            sheet.write(row_date_count, 17, val['actqty'] , title_style_left)
            sheet.write(row_date_count, 18, val['actamount'] , title_style_left)
            row_date_count += 1

        stream = io.BytesIO()

        workbook.save(stream)
        attach_id = self.env['v.excel.output'].create({
            'name': "Detailed Invoice Report",
            'filename': base64.encodestring(stream.getvalue())
        })
        return attach_id.download()    
