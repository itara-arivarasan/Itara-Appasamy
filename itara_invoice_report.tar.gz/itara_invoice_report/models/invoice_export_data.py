# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.import xlwt
import io
from io import StringIO
import base64
import time
import xlwt
from datetime import datetime, date, timedelta
from dateutil import relativedelta
from odoo import models, fields, api, _, exceptions

class InvoiceReport(models.Model):
    _name = 'invoice.report'

    name = fields.Char(string="Name")
    company_id = fields.Many2one('res.company', string='Company', default=lambda self: self.env.user.company_id, readonly=True)
    start_date = fields.Date(string='Start Date', required=True)
    end_date = fields.Date(string='End Date', required=True)

    def get_data(self):
        workbook = xlwt.Workbook()
        title_style_center = xlwt.easyxf('align: horiz center ;font: name Times New Roman,bold off, italic off')
        title_style_left = xlwt.easyxf('font: name Times New Roman, height 200;align: horiz left ')
        title_style_right = xlwt.easyxf('font: name Times New Roman, height 200;align: horiz right ')
        title_style1_table_head_right = xlwt.easyxf(
            'font: name Times New Roman,bold on, italic off, height 200;align: horiz right ;')
        title_style1_table_head_center = xlwt.easyxf(
            'align: horiz center ;font: name Times New Roman,bold on, italic off, height 200')
        title_style1_table_head_left = xlwt.easyxf(
            'align: horiz left ;font: name Times New Roman,bold on, italic off, height 200')
        row_date_count = 0

        #        B2B Invoice

        customers = []
        sheet = workbook.add_sheet('Excel Invoice Report')
        sheet.write(row_date_count, 0, "S.No", title_style1_table_head_center)
        sheet.write(row_date_count, 1, "Year", title_style1_table_head_center)
        sheet.write(row_date_count, 2, "Branch Name", title_style1_table_head_center)
        sheet.write(row_date_count, 3, "DC No", title_style1_table_head_center)
        sheet.write(row_date_count, 4, "DC Date", title_style1_table_head_center)
        sheet.write(row_date_count, 5, "Segment Name", title_style1_table_head_center)
        sheet.write(row_date_count, 6, "Customer Name", title_style1_table_head_center)
        sheet.write(row_date_count, 7, "District Name", title_style1_table_head_center)
        sheet.write(row_date_count, 8, "City Name", title_style1_table_head_center)
        sheet.write(row_date_count, 9, "Untaxed Total", title_style1_table_head_center)
        sheet.write(row_date_count, 10, "Total", title_style1_table_head_center)
        sheet.write(row_date_count, 11, "Return Untaxed Amount", title_style1_table_head_center)
        sheet.write(row_date_count, 12, "Return Amount", title_style1_table_head_center)
        sheet.write(row_date_count, 13, "Actual Untaxed Amount", title_style1_table_head_center)
        sheet.write(row_date_count, 14, "Actual Amount", title_style1_table_head_center)
        sheet.write(row_date_count, 15, "Credit Note", title_style1_table_head_center)
        sheet.write(row_date_count, 16, "Payment Received", title_style1_table_head_center)
        sheet.write(row_date_count, 17, "Balance amount", title_style1_table_head_center)

        row_date_count += 1
        count = 0        
        values = []
        for invoice in self.env['account.invoice'].search([('date_invoice', '>=', self.start_date), ('date_invoice', '<=', self.end_date),('type', '=', 'out_invoice')]):
            for line in invoice.invoice_line_ids:
                return_line = self.env['account.invoice.line'].search([('return_inv', '=', line.return_inv), ('product_id', '=', line.product_id.id), ('invoice_id.type', '=', 'out_refund')])
                if return_line:
                    for rline in return_line:
                        data = {
                        'inv_year': invoice.date_invoice[:-6] or '-',
                        'branch': invoice.partner_id.branch_id.name or '-',
                        'number': invoice.number or '-',
                        'date': invoice.date_invoice or '-',
                        'sub_division': invoice.partner_id.sub_division_id.name or '-',
                        'customer': invoice.partner_id.name or '-',
                        'district': invoice.partner_id.district_id.name or '-',
                        'city': invoice.partner_id.city_id.name or '-',
                        'untaxed_total': invoice.amount_untaxed,
                        'amount_total': invoice.amount_total,
                        'rprice_subtotal': rline.price_subtotal,
                        'ramount_total': rline.price_subtotal_incl1,
                        'actamount': invoice.amount_untaxed - rline.price_subtotal,
                        'actamounttax': invoice.amount_total - rline.price_subtotal_incl1,
                        'payment_received': invoice.amount_total - invoice.residual,
                        'balance_amount': invoice.residual


                         }
                        values.append(data)
                if not return_line:
                    data = {
                        'inv_year': invoice.date_invoice[:-6] or '-',
                        'branch': invoice.partner_id.branch_id.name or '-',
                        'number': invoice.number or '-',
                        'date': invoice.date_invoice or '-',
                        'sub_division': invoice.partner_id.sub_division_id.name or '-',
                        'customer': invoice.partner_id.name or '-',
                        'district': invoice.partner_id.district_id.name or '-',
                        'city': invoice.partner_id.city_id.name or '-',
                        'untaxed_total': invoice.amount_untaxed,
                        'amount_total': invoice.amount_total,
                        'rprice_subtotal': 0.0,
                        'ramount_total': 0.0,
                        'actamount': invoice.amount_untaxed ,
                        'actamounttax': invoice.amount_total,
                        'payment_received': invoice.amount_total - invoice.residual,
                        'balance_amount': invoice.residual

                    }
                    values.append(data)
        for val in values: 
            count += 1
            sheet.write(row_date_count, 0, count, title_style_left)
            sheet.write(row_date_count, 1, val['inv_year'], title_style_left)
            sheet.write(row_date_count, 2, val['branch'], title_style_left)
            sheet.write(row_date_count, 3, val['number'], title_style_left)
            sheet.write(row_date_count, 4, val['date'], title_style_left)
            sheet.write(row_date_count, 5, val['sub_division'], title_style_left)
            sheet.write(row_date_count, 6, val['customer'], title_style_left)
            sheet.write(row_date_count, 7, val['district'], title_style_left)
            sheet.write(row_date_count, 8, val['city'], title_style_left)
            sheet.write(row_date_count, 9, val['untaxed_total'], title_style_left)
            sheet.write(row_date_count, 10, val['amount_total'], title_style_left)
            sheet.write(row_date_count, 11, val['rprice_subtotal'], title_style_left)
            sheet.write(row_date_count, 12, val['ramount_total'], title_style_left)
            sheet.write(row_date_count, 13, val['actamount'] , title_style_left)
            sheet.write(row_date_count, 14, val['actamounttax'] , title_style_left)
            sheet.write(row_date_count, 15, '-', title_style_left)
            sheet.write(row_date_count, 16, val['payment_received'], title_style_left)
            sheet.write(row_date_count, 17, val['balance_amount'], title_style_left)
            row_date_count += 1

        stream = io.BytesIO()

        workbook.save(stream)
        attach_id = self.env['i.excel.output'].create({
            'name': "Invoice Report",
            'filename': base64.encodestring(stream.getvalue())
        })
        return attach_id.download()    
