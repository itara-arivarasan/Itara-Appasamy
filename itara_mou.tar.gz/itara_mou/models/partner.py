from odoo import api, fields, models, _

class res_partner(models.Model):
    _inherit = "res.partner"

    mou_number_id = fields.Many2one('mou.order', string="MOU Number")

class Mou_order(models.Model):
    _name = 'mou.order'
    _description = "Orders"

    name = fields.Char(string="Mou Number", required="1")
    partner_id = fields.Many2one('res.partner', string="Customer", required="1")


class sale_order(models.Model):
    _inherit = "sale.order"

    mou_partner_id = fields.Many2one('mou.order', string="Parent Number")
    mou_number = fields.Selection([('mou', 'MOU'),('other', 'Other Type')], string="MOU", default='other')
    
    @api.onchange('order_type')
    def ochange_order_type(self):
        if self.order_type.name == 'MOU':
            self.mou_number = 'mou'
        else:
            self.mou_number = 'other'



