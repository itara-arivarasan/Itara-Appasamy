from odoo import api, fields, models, _

class Account_Bank(models.Model):
    _name = "account.bank.details"
    name = fields.Char(string="Bank Name")
    
   
class AccountPayment(models.Model):
    _inherit = "account.payment"

    @api.one
    @api.depends('journal_id')
    def get_journal_type(self):
        if self.journal_id:
            self.jtype = self.journal_id.type

    customer_bank_details = fields.Text("Customer Bank Details")
    company_bank_details = fields.Selection([('Indian', 'Indian Bank - IDIB000A132'),('HDFC', 'HDFC - HDFC0000004')])
    cheque_ref = fields.Char("Cheque/DD Ref")
    memo_no1 = fields.Char("Deposited Bank Name")
    memo_no2 = fields.Char("Deposit Date")
    bank_branch_name = fields.Char("Bank Branch Name")
    cheque_date = fields.Date("Cheque/DD Date")
    jtype = fields.Selection([
        ('sale', 'Sale'),
        ('purchase', 'Purchase'),
        ('cash', 'Cash'),
        ('bank', 'Bank'),
        ('general', 'Miscellaneous'),
    ], store=True, compute="get_journal_type",)
    bank = fields.Many2one('account.bank.details', string="Bank", store=True)

    
class AccountPayment(models.TransientModel):
    _inherit = "account.register.payments"

    @api.one
    @api.depends('journal_id')
    def get_journal_type(self):
        if self.journal_id:
            self.jtype = self.journal_id.type

    customer_bank_details = fields.Text("Customer Bank Details")
    company_bank_details = fields.Selection([('Indian', 'Indian Bank - IDIB000A132'),('HDFC', 'HDFC - HDFC0000004')])
    cheque_ref = fields.Char("Cheque/DD Ref")
    memo_no1 = fields.Char("Deposited Bank Name")
    memo_no2 = fields.Char("Deposit Date")
    bank_branch_name = fields.Char("Bank Branch Name")
    cheque_date = fields.Date("Cheque/DD Date")
    jtype = fields.Selection([
        ('sale', 'Sale'),
        ('purchase', 'Purchase'),
        ('cash', 'Cash'),
        ('bank', 'Bank'),
        ('general', 'Miscellaneous'),
    ], store=True, compute="get_journal_type",)
