# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.
{
    'name': 'Account Fields',
    'version': '1.1',
    'summary': 'Itara',
    'description': """Additional Fields in Invoice""",
    'category': 'account',
    'depends': ['product', 'account','sale', 'stock', 'itara_sale_revision'],
    'data': [
            'views/invoice_view.xml',
             'views/payment.xml'],
    'installable': True,
    'application': True,
    'auto_install': False,

}
