from odoo import api, fields, models, _


class account_invoice(models.Model):
    _inherit = "account.invoice"

    @api.one
    @api.depends('origin')
    def _get_sale_id(self):
        if self.origin:
            if 'SO' in self.origin:
                sale = self.env['sale.order'].search([('name', '=', self.origin)])
                self.sale_id = sale.id

    @api.one
    @api.depends('origin')
    def _get_so_date(self):
        if self.origin:
            if 'SO' in self.origin:
                sale = self.env['sale.order'].search([('name', '=', self.origin)])
                sale_id = sale.id
                if sale_id:
                    self.so_date = sale.date_order

    @api.one
    @api.depends('partner_id')
    def _get_group_customer_no(self):
        if self.partner_id:
            self.group_customer_number = self.partner_id.group_customer_no

    @api.one
    @api.depends('partner_id.sequence_id')
    def _get_customer_seq_no(self):
        if self.partner_id:
            self.customer_seq_number = self.partner_id.sequence_id

    sale_id = fields.Many2one("sale.order", string="SO No", compute="_get_sale_id", store=True)
    sale_type = fields.Many2one('sale.type', string="Type", store=True)
    dc_no = fields.Char(string="DC No")
    dc_date = fields.Date(string="DC Date")
    po_no = fields.Char(string="PO No")
    po_date = fields.Date(string="PO Date")
    so_date = fields.Date(string="SO Date", compute="_get_so_date", store=True)
    group_customer_number = fields.Char(string="Group Customer No", compute="_get_group_customer_no", store=True)
    remarks = fields.Selection([
        ('free_sample', 'Free replacement against warranty no commercial value'),
        ('sample_invoice', 'Free sample Invoice'), ])
    customer_seq_number = fields.Char(string="Customer Seq No", compute="_get_customer_seq_no", store=True)


class AccountInvoiceLine(models.Model):
    _inherit = "account.invoice.line"

    @api.one
    @api.depends('product_id')
    def _compute_variant_name(self):
        for rec in self.sudo():
            # display only the attributes with multiple possible values on the template
            variable_attributes = rec.product_id.attribute_line_ids.filtered(lambda l: len(l.value_ids) > 1).mapped(
                'attribute_id')
            variant = rec.product_id.attribute_value_ids._variant_name(variable_attributes)
            self.power = variant

    @api.one
    @api.depends('invoice_id.origin')
    def _compute_serial_number(self):
        for rec in self:
            if rec.invoice_id.type == 'out_invoice':
                if rec.invoice_id.origin:
                    sale_id = self.env['sale.order'].search([('name', '=', rec.invoice_id.origin)])
                    for sale in sale_id:
                        for picking in sale.picking_ids:
                            for pick_line in picking.move_lines:
                                lot_name = []
                                aa = ''
                                if pick_line.product_id == rec.product_id:
                                    move_line = self.env['stock.move.line'].search(
                                        [('move_id', '=', pick_line.id), ('product_id', '=', pick_line.product_id.id)])
                                    for lot in move_line:
                                        lot_name.append(str(lot.lot_name))
                                        aa += str(lot.lot_name) + ' '
                                    lot = str(lot_name).replace('[', '')
                                    lot1 = str(lot).replace("'", "")
                                    lot2 = str(lot1).replace(']', '')
                                    lot3 = str(lot2).replace(',', '')
                                    self.serial_number = lot3

    @api.one
    @api.depends('invoice_id.origin')
    def _compute_pharma_serial_number(self):
        for rec in self:
            if rec.invoice_id.type == 'out_invoice':
                if rec.invoice_id.origin:
                    sale_id = self.env['sale.order'].search([('name', '=', rec.invoice_id.origin)])
                    for sale in sale_id:
                        for picking in sale.picking_ids:
                            for pick_line in picking.move_lines:
                                use_date = []
                                bb = ''
                                if pick_line.product_id == rec.product_id:
                                    move_line = self.env['stock.move.line'].search(
                                        [('move_id', '=', pick_line.id), ('product_id', '=', pick_line.product_id.id)])
                                    for lot in move_line:
                                        lot_prod = lot.lot_id.production_date or ''
                                        lot_udate = lot.lot_id.use_date or ''
                                        lot_mfg = lot.lot_id.production_unit or ''
                                        use_date.append(str('{BatchNo:' + str(lot.lot_name) + '-' + 'MFGDate:' + str(
                                            lot_prod[5:8] + lot_prod[0:4]) + '-' + 'EXP:' + str(
                                            lot_udate[5:8] + lot_udate[0:4]) + '-' + 'MFG:' + str(
                                            lot_mfg) + '}' + '      '))
                                        bb += str('BatchNo:' + str(lot.lot_name) + '-' + 'MFGDate:' + str(
                                            lot_prod[5:8] + lot_prod[0:4]) + '-' + 'EXP:' + str(
                                            lot_udate[5:8] + lot_udate[0:4]) + '-' + 'MFG:' + str(lot_mfg) + '      ')
                                    lots = str(use_date).replace('[', '')
                                    lots1 = str(lots).replace("'", "")
                                    lots2 = str(lots1).replace(']', '')
                                    lots3 = str(lots2).replace(',', '')
                                    self.ph_data = lots3

    power = fields.Char(string="Power", compute='_compute_variant_name', store=True)
    serial_number = fields.Char(string="Serial Number", compute='_compute_serial_number', store=True)
    ph_data = fields.Char(string="Best before Date", compute='_compute_pharma_serial_number', store=True)
    sale_type = fields.Many2one('sale.type', string="Type", store=True, related='invoice_id.sale_type')
    po_date = fields.Date(string="PO Date", related='invoice_id.po_date', store=True)
    so_date = fields.Date(string="SO Date", related='invoice_id.so_date', store=True)
    sale_id = fields.Many2one("sale.order", string="SO No", store=True, related='invoice_id.sale_id')
    date_invoice = fields.Date(string="Invoice Date", related='invoice_id.date_invoice', store=True)
    number = fields.Char(string="Serial Number", store=True, related='invoice_id.number')
    partner_shipping_id = fields.Many2one("res.partner", string="Delivery", store=True,
                                          related='invoice_id.partner_shipping_id')


class res_company_fields(models.Model):
    _inherit = "res.company"

    dl_1_no = fields.Char(string="DL No")
    dl_2_no = fields.Char(string="DL No")


class product_template_fields(models.Model):
    _inherit = "product.template"

    mrp_price = fields.Float(string="MRP Price")


class PurchaseOrder(models.Model):
    _inherit = "purchase.order.line"

    @api.one
    @api.depends('product_id')
    def _compute_variant_purchase_name(self):
        for rec in self.sudo():
            # display only the attributes with multiple possible values on the template
            variable_attributes = rec.product_id.attribute_line_ids.filtered(lambda l: len(l.value_ids) > 1).mapped(
                'attribute_id')
            variant = rec.product_id.attribute_value_ids._variant_name(variable_attributes)
            self.power = variant

    power = fields.Char(string="Power", compute='_compute_variant_purchase_name', store=True)


class Stock_moves(models.Model):
    _inherit = "stock.move"

    @api.one
    @api.depends('product_id')
    def _compute_variant_stock_name(self):
        for rec in self.sudo():
            # display only the attributes with multiple possible values on the template
            variable_attributes = rec.product_id.attribute_line_ids.filtered(lambda l: len(l.value_ids) > 1).mapped(
                'attribute_id')
            variant = rec.product_id.attribute_value_ids._variant_name(variable_attributes)
            self.power = variant

    power = fields.Char(string="Power", compute='_compute_variant_stock_name', store=True)
    serial_no = fields.Char(string="Serial Number", store=True)


class Stock_picking(models.Model):
    _inherit = "stock.picking"

    @api.multi
    def button_validate(self):
        super(Stock_picking, self).button_validate()
        for pick_line in self.move_lines:
            lot_name = []
            aa = ''
            move_line = self.env['stock.move.line'].search(
                [('move_id', '=', pick_line.id), ('product_id', '=', pick_line.product_id.id)])
            if move_line:
                for lot in move_line:
                    lot_name.append(str(lot.lot_name))
                    aa += str(lot.lot_name) + ' '
                lot = str(lot_name).replace('[', '')
                lot1 = str(lot).replace("'", "")
                lot2 = str(lot1).replace(']', '')
                lot3 = str(lot2).replace(',', '')
                pick_line.write({'serial_no': lot3})

        if self._check_backorder():
            return self.action_generate_backorder_wizard()
        self.action_done()
        return
